// const express = require('express');
// const router = express.Router();
// const teacherSubjectsController = require('../controllers/teacherSubjects.controller');

// router.post('/teacher-subject', teacherSubjectsController.createTeacherSubject);
// router.post('/teacher-subject/bulk', teacherSubjectsController.bulkCreateTeacherSubjects);
// router.get('/teacher-subject', teacherSubjectsController.getAllTeacherSubjects);
// router.get('/teacher-subject/:id', teacherSubjectsController.getTeacherSubjectById);
// router.get('/teacher-subject/teacher/:teacher_id', teacherSubjectsController.getSubjectsByTeacherId);
// router.get('/teacher-subject/subject/:subject_id', teacherSubjectsController.getTeachersBySubjectId);
// router.put('/teacher-subject/:id', teacherSubjectsController.updateTeacherSubject);
// router.delete('/teacher-subject/:id', teacherSubjectsController.deleteTeacherSubject);
// router.delete('/teacher-subject/teacher/:teacher_id/all', teacherSubjectsController.deleteAllSubjectsForTeacher);

// module.exports = router; 
    
 

